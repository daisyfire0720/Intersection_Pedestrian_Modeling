from shapely.geometry import Point
from shapely.geometry import LineString
import numpy as np
import math

cell_len = 20
A = 2000
B = -0.08


def takeEight(elem):
    return elem[7]


def takeSix(elem):
    return elem[5]


def normalize(v):
    norm = np.linalg.norm(v)
    if norm == 0:
        return v
    return v / norm


def calc_angle(p0: Point, p1: Point):  # 从p0指向p1的向量与正南方向逆时针的夹角
    angle = 0
    dx, dy = p1.x - p0.x, p1.y - p0.y
    if dx == 0 and dy > 0:
        angle = 0
    if dx == 0 and dy < 0:
        angle = 180
    if dy == 0 and dx > 0:
        angle = 90
    if dy == 0 and dx < 0:
        angle = 270
    if dx > 0 and dy > 0:
        angle = math.atan(dx / dy) * 180 / math.pi
    elif dx < 0 and dy > 0:
        angle = 360 + math.atan(dx / dy) * 180 / math.pi
    elif dx < 0 and dy < 0:
        angle = 180 + math.atan(dx / dy) * 180 / math.pi
    elif dx > 0 and dy < 0:
        angle = 180 + math.atan(dx / dy) * 180 / math.pi
    return round(angle, 2)


def calc_step(p0: Point, p1: Point):
    length = p0.distance(p1)
    angle = calc_angle(p0, p1)
    return round(angle, 2), round(length, 2)


def relat_angle(angle1, angle2):
    inter_ang = angle1 - angle2
    if inter_ang <= -180:
        inter_ang += 360
    elif inter_ang >= 180:
        inter_ang -= 360
    return round(inter_ang, 2)


def vector2polar(v, a):  # 计算向量v相对a的角度
    angle = 0
    dx, dy = v[0], v[1]
    if dx == 0 and dy > 0:
        angle = 0
    if dx == 0 and dy < 0:
        angle = 180
    if dy == 0 and dx > 0:
        angle = 90
    if dy == 0 and dx < 0:
        angle = 270
    if dx > 0 and dy > 0:
        angle = math.atan(dx / dy) * 180 / math.pi
    elif dx < 0 and dy > 0:
        angle = 360 + math.atan(dx / dy) * 180 / math.pi
    elif dx < 0 and dy < 0:
        angle = 180 + math.atan(dx / dy) * 180 / math.pi
    elif dx > 0 and dy < 0:
        angle = 180 + math.atan(dx / dy) * 180 / math.pi
    return relat_angle(angle, a)


def difvec2polar(dif_vector, ref_angle):  # dif_vector相对于ref_angle的角度和向量差的长度
    dv = np.array(dif_vector)
    dis = round(np.linalg.norm(dv), 2)
    angle = vector2polar(dif_vector, ref_angle)
    return [angle, dis]


def polar2vector(angle, dis):
    x = dis * math.sin(angle / 180 * math.pi)
    y = dis * math.cos(angle / 180 * math.pi)
    return [round(x, 2), round(y, 2)]


def rotate_step(angle):
    a = np.array([0, 1])
    alpha = angle / 180 * np.pi
    x_ = a[1] * np.sin(alpha) + a[0] * np.cos(alpha)
    y_ = a[1] * np.cos(alpha) - a[0] * np.sin(alpha)
    return np.array([x_, y_])


def distance_point_to_ray(point, ray_origin, ray_direction):
    # Calculate the vector from the ray origin to the point
    vector_to_point = (point[0] - ray_origin[0], point[1] - ray_origin[1])

    # Calculate the dot product between the vector and the ray direction
    dot_product = vector_to_point[0] * ray_direction[0] + vector_to_point[1] * ray_direction[1]

    # If the dot product is negative, the point is behind the ray
    if dot_product <= 0:
        return math.sqrt(vector_to_point[0] ** 2 + vector_to_point[1] ** 2)

    # Calculate the distance from the point to the ray
    projection_length = dot_product / (ray_direction[0] ** 2 + ray_direction[1] ** 2)
    projection_vector = (projection_length * ray_direction[0], projection_length * ray_direction[1])
    distance_vector = (vector_to_point[0] - projection_vector[0], vector_to_point[1] - projection_vector[1])
    return math.sqrt(distance_vector[0] ** 2 + distance_vector[1] ** 2)


def count_peds(ped_list, max_t):
    ped_list_t = []
    for t in range(max_t):
        tem_list = []
        for p in ped_list:
            if p.start_time <= t <= p.end_time:
                tem_list.append(p)
        ped_list_t.append(tem_list)
    return ped_list_t


class Ped:
    def __init__(self, id: int):
        self.id = id
        self.cm = None
        self.tra = []  # 全路径坐标信息
        self.start_time = None
        self.end_time = None
        self.start_loc = None
        self.end_loc = None
        self.start_cell = None
        self.end_cell = None

        self.cells = []  # 路径元胞信息
        self.tra_string = None  # 轨迹折线
        self.cell_string = None  # 离散后的轨迹折线

        self.oris = None
        self.ob_angle = None
        self.v_vector = None
        self.v_polar = None
        self.cum_time = None
        self.stay_time = None

        self.s_field = []

        self.ob_distance = 200
        self.ob_cells = None
        self.ob_peds = None

        self.nearest_ped = None
        self.nearest_ob = None

        self.step_vector = None
        self.step_vector_simple = None
        self.step_vector_force = None
        self.step_polar = None
        self.step_polar_simple = None
        self.step_polar_force = None

    def get_space(self, cell_mat):
        self.cm = cell_mat

    def get_tra(self, trac, s_time, e_time):
        cell_centers = []  # 路径中元胞中心点集合
        interval = 1  # 采样间隔
        for i in range(len(trac)):
            t = trac[i]
            if s_time <= i <= e_time and i % interval == 0:
                self.tra.append(Point(t[0], t[1]))
                ci, cj = int(t[0] // cell_len), int(t[1] // cell_len)
                self.cells.append(self.cm[ci][cj])
                cell_centers.append(self.cm[ci][cj].poly.centroid)
        self.tra_string = LineString(self.tra)  # 轨迹折线
        self.cell_string = LineString(cell_centers)  # 离散后的轨迹折线
        self.start_time = s_time
        self.end_time = e_time
        self.start_loc = trac[s_time]  # 初始位置
        self.end_loc = trac[e_time]  # 终止位置
        self.start_cell = self.cells[0]  # 初始元胞
        self.end_cell = self.cells[-1]  # 终止元胞

    def get_v(self):
        self.v_vector = []
        self.v_polar = []
        self.v_vector.append([0, 0])
        self.v_polar.append([calc_angle(self.tra[0], self.tra[-1]), 0])
        for i in range(1, len(self.tra)):
            self.v_vector.append([self.tra[i].x - self.tra[i - 1].x, self.tra[i].y - self.tra[i - 1].y])
            angle, length = calc_step(self.tra[i - 1], self.tra[i])
            self.v_polar.append([angle, length])

    def get_orientation(self):
        self.oris = np.zeros(len(self.cells), dtype=int)
        self.oris[0] = calc_angle(self.tra[0], self.tra[-1])
        for i in range(1, len(self.cells)):
            self.oris[i] = calc_angle(self.tra[i - 1], self.tra[-1])
            # self.oris[i] = calc_angle(self.tra[i - 1], self.tra[i])
        self.ob_angle = self.oris

    def get_stay(self):
        self.cum_time = np.zeros(len(self.cells), dtype=int)
        self.stay_time = np.zeros(len(self.cells), dtype=int)
        for i in range(1, len(self.cells)):
            self.cum_time[i] = i
            if self.cells[i] is self.cells[i - 1]:
                self.stay_time[i] = self.stay_time[i - 1] + 1

    def get_s_field(self):
        max_i, max_j = len(self.cm), len(self.cm[0])
        field = np.full([max_i, max_j], 100, dtype=int)
        for i in range(max_i):
            for j in range(max_j):
                if not self.cm[i][j].obstacle:
                    field[i][j] = self.cm[i][j].center.distance(self.tra[-1])
        self.s_field = field

    def get_ob_peds(self, p_list_t):
        self.ob_peds = []
        for t in range(self.end_time - self.start_time + 1):
            ll_ps, lf_ps, ff_ps, rf_ps, rr_ps, rb_ps, bb_ps, lb_ps = [], [], [], [], [], [], [], []
            for p in p_list_t[t + self.start_time]:
                if p is not self:
                    dis = self.tra[t].distance(p.tra[t + self.start_time - p.start_time])
                    if dis <= self.ob_distance:
                        ang = calc_angle(self.tra[t], p.tra[t + self.start_time - p.start_time])
                        inter_ang = relat_angle(ang, self.oris[t])
                        if -112.5 < inter_ang <= -67.5:
                            rr_ps.append(p)
                        elif -67.5 < inter_ang <= -22.5:
                            rf_ps.append(p)
                        elif -22.5 < inter_ang <= 22.5:
                            ff_ps.append(p)
                        elif 22.5 < inter_ang <= 67.5:
                            lf_ps.append(p)
                        elif 67.5 < inter_ang <= 112.5:
                            ll_ps.append(p)
                        elif 112.5 < inter_ang <= 157.5:
                            lb_ps.append(p)
                        elif 157.5 < inter_ang <= 180 or -180 <= inter_ang <= -157.5:
                            bb_ps.append(p)
                        elif -157.5 < inter_ang <= -112.5:
                            rb_ps.append(p)
            self.ob_peds.append([rb_ps, rr_ps, rf_ps, ff_ps, lf_ps, ll_ps, lb_ps, bb_ps])

    def get_ob_cells(self):
        self.ob_cells = []
        for t in range(self.end_time - self.start_time + 1):
            ll_cs, lf_cs, ff_cs, rf_cs, rr_cs, rb_cs, bb_cs, lb_cs = [], [], [], [], [], [], [], []
            for cl in self.cm:
                for c in cl:
                    dis = self.tra[t].distance(c.center)
                    if dis <= self.ob_distance:
                        ang = calc_angle(self.tra[t], c.center)
                        inter_ang = relat_angle(ang, self.oris[t])
                        if -112.5 < inter_ang <= -67.5:
                            rr_cs.append(c)
                        elif -67.5 < inter_ang <= -22.5:
                            rf_cs.append(c)
                        elif -22.5 < inter_ang <= 22.5:
                            ff_cs.append(c)
                        elif 22.5 < inter_ang <= 67.5:
                            lf_cs.append(c)
                        elif 67.5 < inter_ang <= 112.5:
                            ll_cs.append(c)
                        elif 112.5 < inter_ang <= 157.5:
                            lb_cs.append(c)
                        elif 157.5 < inter_ang <= 180 or -180 <= inter_ang <= -157.5:
                            bb_cs.append(c)
                        elif -157.5 < inter_ang <= -112.5:
                            rb_cs.append(c)
            self.ob_cells.append([rb_cs, rr_cs, rf_cs, ff_cs, lf_cs, ll_cs, lb_cs, bb_cs])

    def get_ped_force(self, time, ped_list, ob_angle):
        att_force = 0
        rep_cp = []
        rep_force = 0
        min_cp = 2
        for p in ped_list:
            dif_angle = relat_angle(p.v[time + self.start_time - p.start_time][0], self.oris[time] + ob_angle)
            ang, dis = calc_step(self.tra[time], p.tra[time + self.start_time - p.start_time])
            if abs(dif_angle) < 90:
                # dis = self.tra[time].distance(p.tra[time + self.start_time - p.start_time])
                att_force += A * math.exp((dis / 100) / B)
            elif abs(dif_angle) > 90:
                dis = self.tra[time].distance(p.tra[time + self.start_time - p.start_time])
                rep_force += A * math.exp((dis / 100) / B)
                v_self = self.v[time][1] * rotate_step(self.oris[time] + ob_angle)
                v_ped = p.v[time + self.start_time - p.start_time]
                p_self = self.tra[time]
                p_ped = p.tra[time + self.start_time - p.start_time]
                v_dif = [v_self[0] - v_ped[0], v_self[1] - v_ped[1]]
                rep_cp.append(distance_point_to_ray([p_ped.x, p_ped.y], [p_self.x, p_self.y], v_dif) / 100)
        if len(rep_cp) != 0:
            min_cp = min(rep_cp)
        return round(att_force, 2), round(rep_force, 2), round(min_cp, 2)

    def get_nearest_ped(self, time, ped_list, ref_angle):
        near_list = []  # 记录其他行人[角度，距离，速度角度，速度大小]
        default_pos = polar2vector(self.oris[time] + ref_angle, 200)
        default_near = [default_pos[0], default_pos[1], 0, 0] + [0, 0] + [ref_angle, 200, 0, 0] + [0, 0] + [200]
        s_p = [self.tra[time].x, self.tra[time].y]
        s_v = self.v_vector[time]
        for p in ped_list:
            p_p = [p.tra[time + self.start_time - p.start_time].x, p.tra[time + self.start_time - p.start_time].y]
            p_v = p.v_vector[time + self.start_time - p.start_time]
            dif_p = [p_p[0] - s_p[0], p_p[1] - s_p[1]]
            dif_v = [p_v[0] - s_v[0], p_v[1] - s_v[1]]
            dif_p_polar = difvec2polar(dif_p, self.oris[time])
            dif_v_polar = difvec2polar(dif_v, self.oris[time])
            force = A * math.exp(((dif_p_polar[1] - 40) / 100) / B)
            force_dir = normalize(dif_p)
            force_vector = [force_dir[0] * force * -1, force_dir[1] * force * -1]
            force_polar = difvec2polar(force_vector, self.oris[time])
            v_self = self.v_polar[1] * rotate_step(self.oris[time] + ref_angle)
            v_ped = p.v_vector[time + self.start_time - p.start_time]
            v_dif = [v_self[0] - v_ped[0], v_self[1] - v_ped[1]]
            rep_cp = distance_point_to_ray(p_p, [self.tra[time].x, self.tra[time].y], v_dif)
            near_list.append(dif_p + dif_v + force_vector + dif_p_polar + dif_v_polar + force_polar + [rep_cp])
        near_list.sort(key=takeEight)
        if len(near_list) >= 5:
            nearest_list = near_list[:5]
        else:
            nearest_list = near_list + [default_near] * (5 - len(near_list))
        self.nearest_ped = nearest_list
        return nearest_list

    def get_cell_force(self, time, cell_list):
        cell_force = 0
        for c in cell_list:
            if c.obstacle:
                dis = self.tra[time].distance(c.center)
                cell_force += A * math.exp((dis / 100) / B)
        return round(cell_force, 2)

    def get_nearest_ob(self, time, cell_list, ref_angle):
        near_list = []
        default_pos = polar2vector(self.oris[time] + ref_angle, 200)
        default_near = [default_pos[0], default_pos[1]] + [0, 0] + [ref_angle, 200] + [0, 0]
        s_p = [self.tra[time].x, self.tra[time].y]
        for c in cell_list:
            if c.obstacle:
                o_p = [c.center.x, c.center.y]
                dif_p = [o_p[0] - s_p[0], o_p[1] - s_p[1]]
                dif_p_polar = difvec2polar(dif_p, self.oris[time])
                force = A * math.exp(((dif_p_polar[1] - 20) / 100) / B)
                force_dir = normalize(dif_p)
                force_vector = [force_dir[0] * force * -1, force_dir[1] * force * -1]
                force_polar = difvec2polar(force_vector, self.oris[time])
                near_list.append(dif_p + force_vector + dif_p_polar + force_polar)
        near_list.sort(key=takeSix)
        if len(near_list) != 0:
            nearest_list = near_list[0]
        else:
            nearest_list = default_near
        self.nearest_ob = nearest_list
        return nearest_list

    def get_cell_sf(self, time, cell_list):
        cell_sf = 0
        cell_num = 0
        c_c = self.cells[time]
        for c in cell_list:
            if not c.obstacle and c is not c_c:
                dis = c.center.distance(c_c.center)
                sf_gain = self.s_field[c.i][c.j] - self.s_field[c_c.i][c_c.j]
                cell_sf += sf_gain / dis
                cell_num += 1
        return round(cell_sf / cell_num, 2) if cell_num else 0

    def get_cell_df(self, time, cell_list):
        cell_df = 0
        cell_num = 0
        c_c = self.cells[time]
        for c in cell_list:
            if not c.obstacle and c is not c_c:
                dis = c.center.distance(c_c.center) / 100
                df_gain = c.d_field[time + self.start_time] - c_c.d_field[time + self.start_time]
                cell_df += df_gain / dis
                cell_num += 1
        return round(cell_df / cell_num, 2) if cell_num else 0

    def new_recorder(self):  # 个人坐标统计法
        self.step_vector = []
        self.step_vector_simple = []
        self.step_vector_force = []
        self.step_polar = []
        self.step_polar_simple = []
        self.step_polar_force = []
        for t in range(self.start_time, self.end_time):
            v_ang = relat_angle(self.v_polar[t - self.start_time][0], self.oris[t - self.start_time])
            v_len = self.v_polar[t - self.start_time][1]
            dis2final = self.tra[t - self.start_time].distance(self.tra[-1])
            infor_polar = [self.id, t, self.oris[t - self.start_time], round(dis2final, 2), round(v_ang, 2),
                           round(v_len / 0.48, 2)]
            infor_polar_simple = [self.id, t, self.oris[t - self.start_time], round(dis2final, 2), round(v_ang, 2),
                                  round(v_len / 0.48, 2)]
            infor_polar_force = [self.id, t, self.oris[t - self.start_time], round(dis2final, 2), round(v_ang, 2),
                                 round(v_len / 0.48, 2)]
            infor_vector = [self.id, t, self.tra[-1].x - self.tra[t - self.start_time].x,
                            self.tra[-1].y - self.tra[t - self.start_time].y] + self.v_vector[t - self.start_time]
            infor_vector_simple = [self.id, t, self.tra[-1].x - self.tra[t - self.start_time].x,
                                   self.tra[-1].y - self.tra[t - self.start_time].y] + self.v_vector[t - self.start_time]
            infor_vector_force = [self.id, t, self.tra[-1].x - self.tra[t - self.start_time].x,
                                  self.tra[-1].y - self.tra[t - self.start_time].y] + self.v_vector[t - self.start_time]
            for i in range(len(self.ob_cells[t - self.start_time])):
                angel = -135 + 45 * i
                p_list = self.ob_peds[t - self.start_time][i]
                c_list = self.ob_cells[t - self.start_time][i]
                nearest_peds = self.get_nearest_ped(t - self.start_time, p_list, angel)
                nearest_obs = self.get_nearest_ob(t - self.start_time, c_list, angel)
                for np in nearest_peds:
                    infor_vector.extend(np[0:6])
                    infor_vector.append(np[12])
                    infor_vector_simple.extend(np[0:4])
                    infor_vector_force.extend(np[2:6])
                    infor_polar.extend(np[6:12])
                    infor_polar.append(np[12])
                    infor_polar_simple.extend(np[6:10])
                    infor_polar_force.extend(np[8:12])
                infor_vector.extend(nearest_obs[0:4])
                infor_vector_simple.extend(nearest_obs[0:2])
                infor_vector_force.extend(nearest_obs[2:4])
                infor_polar.extend(nearest_obs[4:8])
                infor_polar_simple.extend(nearest_obs[4:6])
                infor_polar_force.extend(nearest_obs[6:8])

            step_angle, step_length = calc_step(self.tra[t - self.start_time], self.tra[t - self.start_time + 1])
            step_ang = relat_angle(step_angle, self.oris[t - self.start_time])
            step_length = step_length
            if -112.5 < step_ang <= -67.5:
                step_zone = "rr"
            elif -67.5 < step_ang <= -22.5:
                step_zone = "rf"
            elif -22.5 < step_ang <= 22.5:
                step_zone = "ff"
            elif 22.5 < step_ang <= 67.5:
                step_zone = "lf"
            elif 67.5 < step_ang <= 112.5:
                step_zone = "ll"
            elif 112.5 < step_ang <= 157.5:
                step_zone = "lb"
            elif 157.5 < step_ang <= 180 or -180 <= step_ang <= -157.5:
                step_zone = "bb"
            elif -157.5 < step_ang <= -112.5:
                step_zone = "rb"
            infor_polar.extend([round(step_ang, 2), round(step_length, 2), step_zone])
            infor_polar_simple.extend([round(step_ang, 2), round(step_length, 2), step_zone])
            infor_polar_force.extend([round(step_ang, 2), round(step_length, 2), step_zone])
            infor_vector.extend([self.tra[t - self.start_time + 1].x - self.tra[t - self.start_time].x,
                                 self.tra[t - self.start_time + 1].y - self.tra[t - self.start_time].y, step_zone])
            infor_vector_simple.extend([self.tra[t - self.start_time + 1].x - self.tra[t - self.start_time].x,
                                        self.tra[t - self.start_time + 1].y - self.tra[t - self.start_time].y, step_zone])
            infor_vector_force.extend([self.tra[t - self.start_time + 1].x - self.tra[t - self.start_time].x,
                                       self.tra[t - self.start_time + 1].y - self.tra[t - self.start_time].y, step_zone])
            self.step_vector.append(infor_vector)
            self.step_vector_simple.append(infor_vector_simple)
            self.step_vector_force.append(infor_vector_force)
            self.step_polar.append(infor_polar)
            self.step_polar_simple.append(infor_polar_simple)
            self.step_polar_force.append(infor_polar_force)

