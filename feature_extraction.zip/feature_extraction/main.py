import numpy as np
from ped import *
from cell import *
from gui import *
import random
import pickle
import os
import sys
import time
import csv

sys.setrecursionlimit(10000)

np.set_printoptions(threshold=np.inf)

bia_x = 400 + cell_len
bia_y = 100 + cell_len

if __name__ == '__main__':

    if not (os.path.exists('peds_or.pkl') and os.path.exists('cellmat_or.pkl')):
        # for rem in range(0, 12, 3):
        ped_list = []
        cell_mat = []
        for i in range(0, 1200 + 2 * cell_len, cell_len):
            cell_mat.append([])
            for j in range(0, 600 + 2 * cell_len, cell_len):
                if (i < 400 + cell_len or i >= 800 + cell_len) and (j < 120 + cell_len or j >= 480 + cell_len):
                    cell_mat[i // cell_len].append(Cell(i, j, i + cell_len, j + cell_len, ob=True))
                else:
                    cell_mat[i // cell_len].append(Cell(i, j, i + cell_len, j + cell_len))

        # 读取路径
        o_data = np.loadtxt('/Users/zhangbotao/Desktop/Julish exp/CROSSING_90/CROSSING_90_A/crossing_90_a_04.txt')
        time_interval = 12
        tem_list = []
        for d in o_data:
            if int(d[1]) % time_interval == 0:
                d[1] = d[1] // time_interval
                tem_list.append(d)
        data = np.array(tem_list)
        rows = data.shape[0]
        max_list, min_list = np.max(data, axis=0), np.min(data, axis=0)
        max_peds = int(max_list[0])
        max_time, min_time = int(max_list[1]) + 1, int(min_list[1])
        print(min_time)
        print(max_time)
        max_x, min_x = max_list[2], min_list[2]
        max_y, min_y = max_list[3], min_list[3]
        for i in range(max_peds):
            ped_list.append(Ped(i))

        for i in range(max_peds):
            trac = np.zeros([max_time, 2], dtype=float)
            start_time = max_time
            end_time = 0
            for a in data:
                if int(a[0]) == i + 1:
                    time = int(a[1])
                    trac[time][0], trac[time][1] = a[2] + bia_x, a[3] + bia_y
                    if time > end_time:
                        end_time = time
                    if time < start_time:
                        start_time = time
            ped_list[i].get_space(cell_mat)
            ped_list[i].get_tra(trac, start_time, end_time)
            ped_list[i].get_v()
            ped_list[i].get_orientation()

        ped_list_t = count_peds(ped_list, max_time)
        tem_list = []
        for pl in ped_list_t:
            tem_list.append(len(pl))
        print(tem_list)

        for p in ped_list:
            p.get_ob_peds(p_list_t=ped_list_t)
            p.get_ob_cells()
            p.new_recorder()

        f = open('peds_or.pkl', 'wb')
        content = pickle.dumps(ped_list)
        f.write(content)
        f.close()
        f = open('cellmat_or.pkl', 'wb')
        content = pickle.dumps((cell_mat, max_time))
        f.write(content)
        f.close()

    else:
        f = open('peds_or.pkl', 'rb')
        ped_list = pickle.loads(f.read())
        f.close()
        f = open('cellmat_or.pkl', 'rb')
        cell_mat, max_time = pickle.loads(f.read())
        f.close()

        obs = ["rb", "rr", "rf", "ff", "lf", "ll", "lb", "bb"]

        with open("output_8_or/ds_vector.csv", "w") as csvfile:
            writer = csv.writer(csvfile)
            titles = ["id", "time", "dest_x", "dest_y", "v_x", "v_y"]
            inds = ["ped1_x", "ped1_y", "ped1_vx", "ped1_vy", "ped1_fx", "ped1_fy", "ped1_cp",
                    "ped2_x", "ped2_y", "ped2_vx", "ped2_vy", "ped2_fx", "ped2_fy", "ped2_cp",
                    "ped3_x", "ped3_y", "ped3_vx", "ped3_vy", "ped3_fx", "ped3_fy", "ped3_cp",
                    "ped4_x", "ped4_y", "ped4_vx", "ped4_vy", "ped4_fx", "ped4_fy", "ped4_cp",
                    "ped5_x", "ped5_y", "ped5_vx", "ped5_vy", "ped5_fx", "ped5_fy", "ped5_cp",
                    "ob_x", "ob_y", "ob_fx", "ob_fy"]
            for o in obs:
                for i in inds:
                    titles.append(o + "_" + i)
            titles += ["step_x", "step_y", "step_zone"]
            writer.writerow(titles)
            for p in ped_list:
                writer.writerows(p.step_vector)

        with open("output_8_or/ds_vector_simple.csv", "w") as csvfile2:
            writer = csv.writer(csvfile2)
            titles = ["id", "time", "dest_x", "dest_y", "v_x", "v_y"]
            inds = ["ped1_x", "ped1_y", "ped1_vx", "ped1_vy",
                    "ped2_x", "ped2_y", "ped2_vx", "ped2_vy",
                    "ped3_x", "ped3_y", "ped3_vx", "ped3_vy",
                    "ped4_x", "ped4_y", "ped4_vx", "ped4_vy",
                    "ped5_x", "ped5_y", "ped5_vx", "ped5_vy",
                    "ob_x", "ob_y"]
            for o in obs:
                for i in inds:
                    titles.append(o + "_" + i)
            titles += ["step_x", "step_y", "step_zone"]
            writer.writerow(titles)
            for p in ped_list:
                writer.writerows(p.step_vector_simple)

        with open("output_8_or/ds_vector_force.csv", "w") as csvfile3:
            writer = csv.writer(csvfile3)
            titles = ["id", "time", "dest_x", "dest_y", "v_x", "v_y"]
            inds = ["ped1_vx", "ped1_vy", "ped1_fx", "ped1_fy",
                    "ped2_vx", "ped2_vy", "ped2_fx", "ped2_fy",
                    "ped3_vx", "ped3_vy", "ped3_fx", "ped3_fy",
                    "ped4_vx", "ped4_vy", "ped4_fx", "ped4_fy",
                    "ped5_vx", "ped5_vy", "ped5_fx", "ped5_fy",
                    "ob_fx", "ob_fy"]
            for o in obs:
                for i in inds:
                    titles.append(o + "_" + i)
            titles += ["step_x", "step_y", "step_zone"]
            writer.writerow(titles)
            for p in ped_list:
                writer.writerows(p.step_vector_force)

        with open("output_8_or/ds_polar.csv", "w") as csvfile4:
            writer = csv.writer(csvfile4)
            titles = ["id", "time", "ori", "dest_l", "v_a", "v_l"]
            inds = ["ped1_a", "ped1_l", "ped1_va", "ped1_vl", "ped1_fa", "ped1_fl", "ped1_cp",
                    "ped2_a", "ped2_l", "ped2_va", "ped2_vl", "ped2_fa", "ped2_fl", "ped2_cp",
                    "ped3_a", "ped3_l", "ped3_va", "ped3_vl", "ped3_fa", "ped3_fl", "ped3_cp",
                    "ped4_a", "ped4_l", "ped4_va", "ped4_vl", "ped4_fa", "ped4_fl", "ped4_cp",
                    "ped5_a", "ped5_l", "ped5_va", "ped5_vl", "ped5_fa", "ped5_fl", "ped5_cp",
                    "ob_a", "ob_l", "ob_fa", "ob_fl"]
            for o in obs:
                for i in inds:
                    titles.append(o + "_" + i)
            titles += ["step_a", "step_l", "step_zone"]
            writer.writerow(titles)
            for p in ped_list:
                writer.writerows(p.step_polar)

        with open("output_8_or/ds_polar_simple.csv", "w") as csvfile5:
            writer = csv.writer(csvfile5)
            titles = ["id", "time", "ori", "dest_l", "v_a", "v_l"]
            inds = ["ped1_a", "ped1_l", "ped1_va", "ped1_vl",
                    "ped2_a", "ped2_l", "ped2_va", "ped2_vl",
                    "ped3_a", "ped3_l", "ped3_va", "ped3_vl",
                    "ped4_a", "ped4_l", "ped4_va", "ped4_vl",
                    "ped5_a", "ped5_l", "ped5_va", "ped5_vl",
                    "ob_a", "ob_l"]
            for o in obs:
                for i in inds:
                    titles.append(o + "_" + i)
            titles += ["step_a", "step_l", "step_zone"]
            writer.writerow(titles)
            for p in ped_list:
                writer.writerows(p.step_polar_simple)

        with open("output_8_or/ds_polar_force.csv", "w") as csvfile6:
            writer = csv.writer(csvfile6)
            titles = ["id", "time", "ori", "dest_l", "v_a", "v_l"]
            inds = ["ped1_va", "ped1_vl", "ped1_fa", "ped1_fl",
                    "ped2_va", "ped2_vl", "ped2_fa", "ped2_fl",
                    "ped3_va", "ped3_vl", "ped3_fa", "ped3_fl",
                    "ped4_va", "ped4_vl", "ped4_fa", "ped4_fl",
                    "ped5_va", "ped5_vl", "ped5_fa", "ped5_fl",
                    "ob_fa", "ob_fl"]
            for o in obs:
                for i in inds:
                    titles.append(o + "_" + i)
            titles += ["step_a", "step_l", "step_zone"]
            writer.writerow(titles)
            for p in ped_list:
                writer.writerows(p.step_polar_force)

        '''
        if rem == 0:
            with open("data_source_04.csv", "w") as csvfile:
                writer = csv.writer(csvfile)
                titles = ["p_id", "time", "orientation", "distance", "v_angle", "v_value"]
                obs = ["ll", "lf", "ff", "rf", "rr"]
                ind = ["attraction", "repulsion", "close_point", "obstacle", "static_field", "dynamic_field"]
                for o in obs:
                    for i in ind:
                        titles.append(o + "_" + i)
                titles += ["step_angle", "step_length"]
                writer.writerow(titles)
                for p in ped_list:
                    writer.writerows(p.step)
        else:
            with open("data_source_04.csv", 'a+') as csvfile:
                writer = csv.writer(csvfile)
                for p in ped_list:
                    writer.writerows(p.step)
        '''
