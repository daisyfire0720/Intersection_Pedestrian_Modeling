import tkinter as tk
from tkinter import Label
import matplotlib as mpl
import numpy as np
from matplotlib.patches import Wedge
import math

max_density = 4


def draw_star(center_x, center_y, r):
    points = [  # 左上点（A）
        center_x - int(r * math.sin(2 * math.pi / 5)),
        center_y - int(r * math.cos(2 * math.pi / 5)),
        # 右上点（C）
        center_x + int(r * math.sin(2 * math.pi / 5)),
        center_y - int(r * math.cos(2 * math.pi / 5)),
        # 左下点（E）
        center_x - int(r * math.sin(math.pi / 5)),
        center_y + int(r * math.cos(math.pi / 5)),
        # 顶点（B）
        center_x,
        center_y - r,
        # 右下点（D）
        center_x + int(r * math.sin(math.pi / 5)),
        center_y + int(r * math.cos(math.pi / 5))]
    return points


def get_max_d_field(c_mat):
    max_f = 0
    for c_l in c_mat:
        for c in c_l:
            if np.max(c.d_field) > max_f:
                max_f = np.max(c.d_field)
    return max_f


def density2color(density, cmap, max_vlue=max_density):
    # 将密度值转化为颜色
    norm = mpl.colors.Normalize(vmin=0, vmax=max_vlue)
    cmap = mpl.cm.get_cmap(cmap)
    list = cmap(norm(density))
    str = '#%02x%02x%02x' % (round(list[0] * 255), round(list[1] * 255), round(list[2] * 255))
    return str


class Gui:
    def __init__(self):
        """设置窗体"""
        self.top = tk.Tk()
        self.top.title("Trajectory reproducing")
        self.top.geometry("1400x750")
        self.top.resizable(width=False, height=False)
        """设置画布"""
        self.c = tk.Canvas(self.top, width=1400, height=700, bg="#FFFFFF")
        self.c.pack(side='bottom')
        self.label = Label(self.top, text="Peds = 0")
        self.label.pack(side='left')
        self.label = Label(self.top, text="Time =  s")
        self.label.pack(side='right')

    def update_cell(self, c_mat, time):
        self.c.delete('cell')
        for c_l in c_mat:
            for c in c_l:
                if not c.obstacle:
                    color = density2color(c.nums[time], "Reds")
                    self.c.create_polygon(list(c.poly.exterior.coords), fill=color, outline='#000000', width=1,
                                          tags='cell')

    def update_ped(self, p_list, time):
        self.c.delete('ped')
        for p in p_list:
            if p.start_time <= time <= p.end_time:
                x, y = p.tra[time - p.start_time].x, p.tra[time - p.start_time].y
                self.c.create_oval(x - 10, y - 10, x + 10, y + 10, fill='#E10303', tags='ped')

    def draw_tra(self, p):
        self.c.create_line(list(p.tra_string.coords), fill='#71EF7E', width=2)

    def draw_cell_tra(self, p):
        self.c.create_line(list(p.cell_string.coords), fill='#005800', width=2)

    def draw_cell(self, c_mat):
        for c_l in c_mat:
            for c in c_l:
                if not c.obstacle:
                    self.c.create_polygon(list(c.poly.exterior.coords), fill='#FFFFFF', outline='#000000', width=1,
                                          tags='cell')

    def draw_s_field(self, ped):
        max_f = 0
        for i in range(len(ped.cm)):
            for j in range(len(ped.cm[0])):
                if ped.s_field[i][j] != 100 and ped.s_field[i][j] > max_f:
                    max_f = ped.s_field[i][j]
        for i in range(len(ped.cm)):
            for j in range(len(ped.cm[0])):
                value = ped.s_field[i][j]
                cell = ped.cm[i][j]
                if not cell.obstacle:
                    color = density2color(value, "Reds", max_vlue=max_f)
                    self.c.create_polygon(list(cell.poly.exterior.coords), fill=color, outline='#000000', width=1,
                                          tags='cell')

    def draw_d_field(self, c_mat, time):
        self.c.delete('d_field')
        for c_l in c_mat:
            for c in c_l:
                if not c.obstacle:
                    color = density2color(c.d_field[time], "Reds", max_vlue=get_max_d_field(c_mat))
                    self.c.create_polygon(list(c.poly.exterior.coords), fill=color, outline='#000000', width=1,
                                          tags='d_field')
                    self.c.create_text(c.poly.centroid.x, c.poly.centroid.y, text=round(c.nums[time], 2),
                                       font=('Times', 9),
                                       tag='d_field')

    def draw_nums(self, c_mat, time):
        self.c.delete('nums')
        for c_l in c_mat:
            for c in c_l:
                if not c.obstacle:
                    color = density2color(c.dir_nums[time][8], "Reds", max_vlue=20)
                    self.c.create_polygon(list(c.poly.exterior.coords), fill=color, outline='#000000', width=1,
                                          tags='nums')
                    self.c.create_text(c.poly.centroid.x, c.poly.centroid.y, text=round(c.dir_nums[time][8], 2),
                                       font=('Times', 9),
                                       tag='nums')

    def draw_oris(self, p):
        print(len(p.oris))
        for i in range(len(p.oris) - 2):
            print(len(p.tra))
            print(len(p.decisions))
            if p.decisions[i] != 8:
                self.c.create_text(p.cells[i].poly.centroid.x + 5, p.cells[i].poly.centroid.y + 5,
                                   text=round(p.oris[i], 2), font=('Times', 9), tag='oris')
                self.c.create_text(p.cells[i].poly.centroid.x - 5, p.cells[i].poly.centroid.y - 5,
                                   text=round(p.decisions[i], 2), font=('Times', 9), tag='oris')

    def draw_ob(self, p_list, time):
        self.c.delete('ob')
        for p in p_list:
            print(p.id)
            if p.start_time <= time <= p.end_time:
                for i in range(5):
                    color = density2color(i, 'coolwarm', max_vlue=5)
                    for cell in p.ob_cells[time - p.start_time][i]:
                        self.c.create_polygon(list(cell.poly.exterior.coords), fill=color, outline='#000000', width=1,
                                              tags='ob')
                    color2 = density2color(i, 'coolwarm_r', max_vlue=5)
                    for ped in p.ob_peds[time - p.start_time][i]:
                        px, py = ped.tra[time - ped.start_time].x, ped.tra[time - ped.start_time].y
                        self.c.create_oval(px - 10, py - 10, px + 10, py + 10, fill=color2, tags='ob')
                x, y = p.tra[time - p.start_time].x, p.tra[time - p.start_time].y
                self.c.create_oval(x - 10, y - 10, x + 10, y + 10, fill='#2F4858', tags='ob')
                semicircle = Wedge((x, y), 200, -22.5 - p.oris[time - p.start_time],
                                   202.5 - p.oris[time - p.start_time])
                self.c.create_polygon(semicircle.get_path().to_polygons()[0].tolist(), fill='', outline='#000000',
                                      width=1, tags='ob')
            self.c.create_polygon(draw_star(p.tra[-1].x, p.tra[-1].y, 20), fill='#2F4858', tags='ob')

    def update_gui(self):
        self.top.update()
        self.c.update()

    def update_time(self, time):
        self.label['text'] = "Timestep = " + str(time)

    def start(self):
        self.top.mainloop()
