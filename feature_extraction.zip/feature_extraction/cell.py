from shapely.geometry import Polygon
import numpy as np

cell_len = 20
diffusion = 0.3
decay = 0.1


def count_d_field(c_mat, max_t):
    for c_l in c_mat:
        for c in c_l:
            c.phero = np.zeros(max_t, dtype=int)
            c.d_field = np.zeros(max_t, dtype=float)
    for t in range(0, max_t - 1):
        for c_l in c_mat:
            for c in c_l:
                c.count_d_field(t)


class Cell:
    def __init__(self, x1, y1, x2, y2, ob=False):
        self.i = x1 // cell_len  # 行号
        self.j = y1 // cell_len  # 列号
        self.loc = [x1, y1, x2, y2]
        self.poly = Polygon([(x1, y1), (x2, y1), (x2, y2), (x1, y2)])
        self.center = self.poly.centroid
        self.obstacle = ob
        self.neighbor = []
        self.ex = [x1, y1, x1, y2, x2, y2, x2, y1]

        self.nums = None
        self.peds = None
        self.dir_nums = None

        self.phero = None  # 信息素
        self.d_field = None

    def get_neighbors(self, cm):
        for i in range(max(self.i - 1, 0), min(self.i + 2, len(cm))):
            for j in range(max(self.j - 1, 0), min(self.j + 2, len(cm[i]))):
                if (i != self.i or j != self.j) and not cm[i][j].obstacle:
                    self.neighbor.append(cm[i][j])

    def count_ped(self, ped_list, max_t):
        self.nums = np.zeros(max_t, dtype=int)
        self.peds = []
        if not self.obstacle:
            for t in range(max_t):
                self.peds.append([])
                for p in ped_list:
                    if p.start_time <= t <= p.end_time and p.cells[t - p.start_time] is self:
                        self.nums[t] += 1
                        self.peds[t].append(p)

    def count_d_field(self, t):
        if not self.obstacle:
            outflow = list(set(self.peds[t]).difference(set(self.peds[t + 1])))
            self.phero[t + 1] = len(outflow)
            if t != 0:
                self.d_field[t] = (1 - decay - diffusion) * self.d_field[t - 1] + self.phero[t - 1]
                for n in self.neighbor:
                    self.d_field[t] += 0.125 * diffusion * n.d_field[t - 1]
                self.d_field[t] = round(self.d_field[t], 2)
